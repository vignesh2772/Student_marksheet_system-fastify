let items = [
  { id: 's1', name: 'Student 1', subject_1: '100', subject_2: '98', subject_3: '76', subject_4: '82', subject_5: '92'},
  { id: 's2', name: 'Student 2 ', subject_1: '92', subject_2: '100', subject_3: '98', subject_4: '76', subject_5: '82' },
  { id: 's3', name: 'Student 3 ', subject_1: '76', subject_2: '92', subject_3: '100', subject_4: '98', subject_5: '96' },
  { id: 's4', name: 'Student 4 ', subject_1: '82', subject_2: '76', subject_3: '92', subject_4: '100', subject_5: '98' },
]

module.exports = items
