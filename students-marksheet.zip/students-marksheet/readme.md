# Fastify-student-marksheet

Fastify-student-marksheet - Create a simple student marksheet system, where we are able to add student details update/delete data.

## Usage

```
npm install

npm run dev
```

### Swagger docs

Visit http://localhost:5000/docs

### REST Client

The file **test.http** can be used to make requests if you are using the [VSCode Rest Client extension](https://marketplace.visualstudio.com/items?itemName=humao.rest-client)
